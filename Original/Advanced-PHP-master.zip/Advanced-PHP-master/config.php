<?php
session_start();

// Define Database Params

define("DB_HOST", "localhost");
define("DB_USER", "root"); // Write your mysql username here
define("DB_PASSWORD", ""); // Your database password
define("DB_NAME", "question2answer"); // Your database name

// Define Url

define("ROOT_PATH", "/");
define("ROOT_URL", "http://localhost/advanced-php/");